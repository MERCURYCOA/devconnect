module.exports = {
    // mongoURI: process.env.MONGO_URI,
    mongoURI: 'mongodb://localhost:27017/devconnect',
    // secretOrKey: process.env.SECRET_OR_KEY
    secretOrKey: 'secret'
};
